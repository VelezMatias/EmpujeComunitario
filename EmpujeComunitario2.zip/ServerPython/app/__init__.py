# app/__init__.py
# vacío o con config básica