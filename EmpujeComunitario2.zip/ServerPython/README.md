# EmpujeComunitario
Proyecto ONG EmpujeComunitario con sistemas distribuidos 
