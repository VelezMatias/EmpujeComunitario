import os
from dotenv import load_dotenv

load_dotenv()

DB_URL = "mysql+pymysql://empuje:empuje123@localhost:3306/empujecomunitario"
GRPC_HOST = "0.0.0.0"
GRPC_PORT = 50051
