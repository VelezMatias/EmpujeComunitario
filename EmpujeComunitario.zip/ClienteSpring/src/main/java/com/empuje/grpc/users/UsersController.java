package com.empuje.grpc.users;

import org.springframework.web.bind.annotation.*;

import com.empuje.grpc.users.UsersServiceGrpc;
import com.empuje.grpc.users.LoginRequest;
import com.empuje.grpc.users.LoginResponse;
import com.empuje.grpc.users.CreateUserRequest;
import com.empuje.grpc.users.CreateUserResponse;
import com.empuje.grpc.users.GetUserRequest;
import com.empuje.grpc.users.GetUserResponse;

@RestController
@RequestMapping("/api/users")
public class UsersController {

    private final UsersServiceGrpc.UsersServiceBlockingStub stub;

    public UsersController(UsersServiceGrpc.UsersServiceBlockingStub stub) {
        this.stub = stub;
    }

    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest request) {
        return stub.login(request);
    }

    @PostMapping
    public CreateUserResponse create(@RequestBody CreateUserRequest request) {
        return stub.createUser(request);
    }

    @GetMapping("/{id}")
    public GetUserResponse get(@PathVariable long id) {
        return stub.getUser(GetUserRequest.newBuilder().setId(id).build());
    }
}
