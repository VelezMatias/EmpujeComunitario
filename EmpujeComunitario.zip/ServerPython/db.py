# db.py
# Conexión simple a MySQL usando PyMySQL y variables de entorno.

import os
import pymysql
from dotenv import load_dotenv

# Cargar variables desde .env
load_dotenv()

def get_connection():
    return pymysql.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "3306")),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASS", ""),
        database=os.getenv("DB_NAME", "empujecomunitario"),
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True,
    )
