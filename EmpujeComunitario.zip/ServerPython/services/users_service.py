# services/users_service.py
# Implementación del servicio gRPC de usuarios usando la BD MySQL.

import grpc
import users_pb2, users_pb2_grpc
from repository.users_repo import UsersRepo

class UsersService(users_pb2_grpc.UsersServiceServicer):

    def CreateUser(self, request, context):
        if not request.username or not request.password:
            context.abort(code=grpc.StatusCode.INVALID_ARGUMENT,
                          details="username y password son obligatorios")

        existing = UsersRepo.get_by_username(request.username)
        if existing:
            context.abort(code=grpc.StatusCode.ALREADY_EXISTS,
                          details="username ya existe")

        user_id = UsersRepo.create(
            username=request.username,
            nombre=request.nombre,
            apellido=request.apellido,
            email=request.email,
            telefono=request.telefono if hasattr(request, "telefono") else "",
            password=request.password,
            rol_id=request.rol_id if request.rol_id else 4  # VOLUNTARIO por defecto
        )
        return users_pb2.CreateUserResponse(user=users_pb2.User(
            id=user_id,
            username=request.username,
            nombre=request.nombre,
            apellido=request.apellido,
            email=request.email,
            telefono=request.telefono if hasattr(request, "telefono") else "",
            rol_id=request.rol_id if request.rol_id else 4,
            activo=True
        ))

    def Login(self, request, context):
        u = UsersRepo.get_by_username(request.username)
        if not u:
            return users_pb2.LoginResponse(ok=False, mensaje="Usuario no encontrado")
        ok = (u["password"] == request.password)
        user_msg = users_pb2.User(
            id=u["id"], username=u["username"], nombre=u["nombre"],
            apellido=u["apellido"], email=u["email"],
            telefono=u["telefono"], rol_id=u["rol_id"], activo=bool(u["activo"])
        ) if ok else None
        return users_pb2.LoginResponse(ok=ok, mensaje="OK" if ok else "Credenciales inválidas", user=user_msg)

    def GetUser(self, request, context):
        u = UsersRepo.get_by_id(request.id)
        if not u:
            context.abort(code=grpc.StatusCode.NOT_FOUND, details="Usuario no encontrado")
        return users_pb2.GetUserResponse(user=users_pb2.User(
            id=u["id"], username=u["username"], nombre=u["nombre"],
            apellido=u["apellido"], email=u["email"],
            telefono=u["telefono"], rol_id=u["rol_id"], activo=bool(u["activo"])
        ))

    def ListUsers(self, request, context):
        # Implementación simple: filtramos en SQL o acá si luego agregás método en repo
        # Por ahora devolvemos los activos si only_active=true (dejá para iteración siguiente)
        context.abort(code=grpc.StatusCode.UNIMPLEMENTED, details="ListUsers pendiente")
