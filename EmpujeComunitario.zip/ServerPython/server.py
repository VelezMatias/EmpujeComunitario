import os, sys
from concurrent import futures
import grpc

# Garantiza que se vea la carpeta actual al ejecutar desde VSCode/terminal
sys.path.append(os.path.dirname(__file__))

# Stubs generados
import users_pb2_grpc

# Implementación
from services.users_service import UsersService

def serve():
    port = os.getenv("GRPC_PORT", "50051")
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))

    users_pb2_grpc.add_UsersServiceServicer_to_server(UsersService(), server)

    server.add_insecure_port(f"[::]:{port}")
    print(f"[gRPC][Python] Escuchando en 0.0.0.0:{port} ...")
    server.start()
    server.wait_for_termination()

if __name__ == "__main__":
    serve()
